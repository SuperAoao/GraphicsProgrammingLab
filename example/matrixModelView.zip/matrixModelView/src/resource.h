//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by matrixModelView.rc
//
#define IDD_FORMVIEW                    101
#define IDT_TIMER                       101
#define IDD_ABOUT                       102
#define IDB_BITMAP_SONGHO               103
#define IDI_ICON1                       106
#define IDC_M_MV_0                      1001
#define IDC_M_MV_1                      1002
#define IDC_M_MV_2                      1003
#define IDC_M_MV_3                      1004
#define IDC_M_MV_4                      1005
#define IDC_M_MV_5                      1006
#define IDC_M_MV_6                      1007
#define IDC_M_MV_7                      1008
#define IDC_M_MV_8                      1009
#define IDC_M_MV_9                      1010
#define IDC_M_MV_10                     1011
#define IDC_M_MV_11                     1012
#define IDC_M_MV_12                     1013
#define IDC_M_MV_13                     1014
#define IDC_M_MV_14                     1015
#define IDC_M_MV_15                     1016
#define IDC_M_V_0                       1017
#define IDC_M_V_1                       1018
#define IDC_M_V_2                       1019
#define IDC_M_V_3                       1020
#define IDC_M_V_4                       1021
#define IDC_M_V_5                       1022
#define IDC_M_V_6                       1023
#define IDC_M_V_7                       1024
#define IDC_M_V_8                       1025
#define IDC_M_V_9                       1026
#define IDC_M_V_10                      1027
#define IDC_M_V_11                      1028
#define IDC_M_V_12                      1029
#define IDC_M_V_13                      1030
#define IDC_M_V_14                      1031
#define IDC_M_V_15                      1032
#define IDC_M_M_0                       1033
#define IDC_M_M_1                       1034
#define IDC_M_M_2                       1035
#define IDC_M_M_3                       1036
#define IDC_M_M_4                       1037
#define IDC_M_M_5                       1038
#define IDC_M_M_6                       1039
#define IDC_M_M_7                       1040
#define IDC_M_M_8                       1041
#define IDC_M_M_9                       1042
#define IDC_M_M_10                      1043
#define IDC_M_M_11                      1044
#define IDC_M_M_12                      1045
#define IDC_M_M_13                      1046
#define IDC_M_M_14                      1047
#define IDC_M_M_15                      1048
#define IDC_BUTTON_VIEW_RESET           1057
#define IDC_BUTTON_MODEL_RESET          1070
#define IDC_SLIDER_VIEW_PX              1078
#define IDC_SLIDER_VIEW_PY              1079
#define IDC_SLIDER_VIEW_PZ              1080
#define IDC_SLIDER_VIEW_RX              1081
#define IDC_SLIDER_VIEW_RY              1082
#define IDC_SLIDER_VIEW_RZ              1083
#define IDC_LABEL_VIEW_PX               1084
#define IDC_LABEL_VIEW_PY               1085
#define IDC_LABEL_VIEW_PZ               1086
#define IDC_LABEL_VIEW_RX               1087
#define IDC_LABEL_VIEW_RY               1088
#define IDC_LABEL_VIEW_RZ               1089
#define IDC_SLIDER_MODEL_PX             1090
#define IDC_SLIDER_MODEL_PY             1091
#define IDC_SLIDER_MODEL_PZ             1092
#define IDC_SLIDER_MODEL_RX             1093
#define IDC_SLIDER_MODEL_RY             1094
#define IDC_SLIDER_MODEL_RZ             1095
#define IDC_LABEL_MODEL_PX              1096
#define IDC_LABEL_MODEL_PY              1097
#define IDC_LABEL_MODEL_PZ              1098
#define IDC_LABEL_MODEL_RX              1099
#define IDC_LABEL_MODEL_RY              1100
#define IDC_LABEL_MODEL_RZ              1101
#define IDC_LABEL_VIEW_GL               1102
#define IDC_LABEL_MODEL_GL              1103
#define IDC_OK                          1104
#define IDC_SYSLINK1                    1107
#define IDC_BUTTON_ABOUT                1108

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1109
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
